<?php
if (isset($_POST['submit'])) {
    $title = mysqli_real_escape_string($connection, $_POST['title']);
    $photo = mysqli_real_escape_string($connection, $_POST['photo']); 
    $brief_description = mysqli_real_escape_string($connection, $_POST['brief_description']);
    $full_description = mysqli_real_escape_string($connection, $_POST['full_description']);
    $category = mysqli_real_escape_string($connection, $_POST['category']);
    $s_admin=$_SESSION['admin'];
    $sql="INSERT INTO `articles` (`title`, `admin`, `brief_description`, `full_description`, `category`, `photo`) VALUES ('$title', '$s_admin', '$brief_description', '$full_description', '$category', '$photo');";
       mysqli_query($connection, $sql);
      
}
 $sql2 = mysqli_query($connection,"SELECT `cat_name` AS cat_name,`cat_id` AS cat_id  FROM `category`");
?>
    <script src="ckeditor/ckeditor.js"></script>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-9">
                <h2 class="text-center">Додавання на сайт новини</h2>
                <form action="" class="add_news_form" method="post">
                    <div class="form-group">
                        <h3>Заголовок</h3>
                        <div class="input-group margin-bottom-sm">
                            <span class="input-group-addon"><i class="fa newspaper-o fa-fw"></i></span>
                            <input class="form-control" type="text" name="title" >
                        </div>  
                        <h3>Виберіть категорію</h3>
                        <select class="form-control" name="category">
                             
                                <?php
                                    while ($row = mysqli_fetch_assoc($sql2)) 
                                    {
                                        echo '<option value="'.$row['cat_id'].'">'.$row['cat_name'].'</option>';
                                    }  
                                  ?>
                            </select>
                        <h3>Короткий опис</h3>
                        <div class="input-group margin-bottom-sm">
                            <textarea class="form-control" type="text" name="brief_description">
                            </textarea>
                        </div>
                        <div class="input-group">
                        <h3>Повний опис</h3>
                            <textarea style="width:100%" name="full_description"></textarea>
                            <script>
                              CKEDITOR.replace('full_description',{'filebrowserBrowseUrl':'/ckeditor/kcfinder/browse.php?type=files',
                              'filebrowserImageBrowseUrl':'/ckeditor/kcfinder/browse.php?type=images',
                              'filebrowserFlashBrowseUrl':'/ckeditor/kcfinder/browse.php?type=flash',
                              'filebrowserUploadUrl':'/ckeditor/kcfinder/upload.php?type=files',
                              'filebrowserImageUploadUrl':'/ckeditor/kcfinder/upload.php?type=images',
                              'filebrowserFlashUploadUrl':'/ckeditor/kcfinder/upload.php?type=flash'});
                            </script>
                        </div>
                        <h3>Додати мініатюру </р3>
                        <div class="input-group margin-bottom-sm">
                            <input class="form-control" type="file" name="photo">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-md" name="submit">Додати статтю</button>
                </form>
                    </div>