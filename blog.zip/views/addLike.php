<?php
	if(isset($_SESSION['id']) && $_GET["id"]){
		$conn = $connection;
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "INSERT INTO likes (
			`user_id`, `article_id`
		) VALUES (
			'".mysqli_real_escape_string($conn,$_SESSION['id'])."', 
			'".mysqli_real_escape_string($conn,$_GET["id"])."'
		);";

		if ($conn->query($sql) === TRUE) {
			echo '<script type="text/javascript">'; 
			echo 'window.history.back();'; 
			echo '</script>'; 
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	}else{
		$url = "/index.php?action=login";
		echo '<script type="text/javascript">'; 
		echo 'window.location.href="'.$url.'";'; 
		echo '</script>'; 
	}
	

?>