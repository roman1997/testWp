 
<!--
session_start();//підключаємо сесію яка була створена раніше
session_destroy();//видаляємо всю інфу з сесії
echo "ВИ вийшли зі свого аккаунта";

header("Location: ./test.php");
//повинна використовуватися до першого виводу на екран
//utf8_unicode_ci - не чутливо до  регістру
//utf8_bin - 
-->

<!--
id   |
*/
//SQL
//CREATE TABLE `coin`.`users` ( `id` INT NOT NULL AUTO_INCREMENT , `login` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`(10))) ENGINE = InnoDB;
-->
 
<!--<a href="./test.php">Назад</a>-->
<?php
	if (!empty($_SESSION['login']) and $_SESSION['login']){
		session_destroy();
		//setcookie('login', '', time());
    echo '<script>window.location.href = "index.php?action=main";</script>';
	}
?>
