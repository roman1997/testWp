<?php
	if(isset($_SESSION['id']) && $_GET["id"]){

		$sql = 
            "DELETE FROM likes 
            WHERE `user_id`='".$_SESSION['id']."' AND `article_id`='".$_GET["id"]."'";

		if ($mysqli->query($sql) === TRUE) {
			echo '<script type="text/javascript">'; 
			echo 'window.history.back();'; 
			echo '</script>'; 
		} else {
			echo "Error: " . $sql . "<br>" . $mysqli->error;
		}

		$mysqli->close();
	}else{
		$url = "/index.php?action=login";
		echo '<script type="text/javascript">'; 
		echo 'window.location.href="'.$url.'";'; 
		echo '</script>'; 
	}
	

?>