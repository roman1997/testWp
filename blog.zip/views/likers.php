   <p>лайкнули користувачі з таким id</p>
<?
    $id = (int)$_GET['id'];
    $result = mysqli_query($mysqli, "SELECT * FROM likes,users WHERE phone_id = $id"); 
    while ($row = mysqli_fetch_array($result)){
?>
<div>
    <?=$row['user_id']?>
</div>
<? }

//		if ($result) {
//			echo '<script type="text/javascript">'; 
//			echo 'window.history.back();'; 
//			echo '</script>'; 
//		} else {
//			echo "Error: ";
//		}

		//$mysqli->close();

?>