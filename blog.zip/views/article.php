<?php
    $id = (int)$_GET['id'];
    $result = mysqli_query($connection, "SELECT * FROM articles WHERE article_id = $id"); 
    $row = mysqli_fetch_array($result);
if(isset($_POST['submit'])){
    
     $comentator = mysqli_real_escape_string($connection, $_POST['comentator']);
     $coment = mysqli_real_escape_string($connection, $_POST['coment']);
     $addcoment=mysqli_query($connection,"INSERT INTO comments(`comentator`,`coment`,`user_id`) VALUES('$comentator','$coment','".$_SESSION['id']."')");
}
?>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-9">

                <div class="articles">
                    <h2><?=$row['title']?></h2>
                    <div class="describe">
                       <img width="100%" src="./img/<?=$row['photo']?>" alt="">
                    <p>
                        <?=$row['full_description']?>
                    </p> 
                    </div>
                    
<?php
                    
?>
                     <div class="like">
                          <a href="index.php?action=addLike&id=<?=$row['article_id']?>">like</a>
                    </div>
                    <div class="comment">
                        <form action="" method="post">
                            <h2>Ваш коментар</h2>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="pwd">Ім'я:</label>
                                <input type="text" class="form-control" id="pwd" name="comentator" placeholder="Roman">
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2" for="comen">Текст коментаря:</label>
                                <textarea name="coment" class="form-control" id="comen" cols="30" rows="10">

                                </textarea>
                            </div>
                            <button name="submit" class="btn btn-success">Додати коментар</button>
                    </div>
                   
                    </form>
                </div>
            </div>