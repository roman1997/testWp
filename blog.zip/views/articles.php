<?php
        
    $sql = "SELECT * FROM articles";
    $result = $connection->query($sql);
  
?>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-9">

                <div class="articles">
                    <div class="row">
                        <?php
                  if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()){
                    ?>
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <article>
                                        <img width="100%" height="200" src="./img/<?=$row['photo'];?>" alt="">
                                    <h2><a href="?action=article&id=<?=$row['article_id'] ?>"><?= $row['title']; ?></a></h2>
                                    <?=$row['brief_description'];?>
                                </article>
                            </div>
                            <?php  }    }   ?>
                    </div>

                </div>
            </div>