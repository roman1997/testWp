<?php

if(isset($_POST['submit'])) {
    $login = $_POST['login'];
    $pass = $_POST['password'];
  $result = mysqli_query($connection,"SELECT * FROM users WHERE login = '$login'");
    if ($result){
        $row = $result->fetch_assoc();
        if( ($login==$row['login'])||($pass==$row['password']) ){
            //( password_verify($pass, $row['password']) ){
            $_SESSION['id'] = $row['id'];
            $_SESSION['admin'] = $row['admin'];
            $_SESSION['login'] = $login;
            echo '<script>window.location.href = "index.php?action=main";</script>';
        }
        else {echo "Неправильный пароль";}
    }
    else {echo "no db ";}

    $connection->close();
}
?>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-9">
                <h2>Вхід на сайт</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <div class="input-group margin-bottom-sm">
                            <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                            <input class="form-control" type="text" name="login" placeholder="username">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                            <input class="form-control" name="password" type="password" placeholder="password">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-md" name="submit">Увійти</button>
                </form>
            </div>