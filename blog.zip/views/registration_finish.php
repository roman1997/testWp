<div id="registration_finish">
	<div class="col-sm-9">
		<h2 class="text-center">Вітаємо ,<?php echo $_SESSION['login']; ?> ви успішно зареєструвалися</h2>
					<br>
		<a href="./index.php">вихід</a>
	</div>
</div>
 