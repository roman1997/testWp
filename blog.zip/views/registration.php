<?php
    $error_login = "";
    $error_email = "";
    $error_pasword = "";
    $error_confirm = "";
if (isset($_POST['submit'])) {
    $login = $_POST['login'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $r_password = $_POST['r_password'];
    if(!preg_match('/[a-z0-9_-а-яєїіґ]{4,255}/i', $login)) {
        $error_login .= 'ВВедіть логін не менше 4 символів!';
    }
    if(!preg_match('/[0-9a-z_-]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i', $email)) {
        $error_email .= "Некоректний email!";
    }
    if(!preg_match('/[a-z0-9_-а-яєїіґ]{7,255}/i', $password)) {
        $error_pasword .= "Некоректний пароль!";
    }
    else if ($password !=$r_password) {
        $error_confirm .= "Паролі не однакові!";
    }
    else{
        $password=password_hash($password,PASSWORD_DEFAULT);
    }
   
    if ($error_confirm == "" && $error_email == "" && $error_login =="" && $error_pasword == "") 
    {
        $sql = mysqli_query($connection,"INSERT INTO `users` (`login`,`password`, `email`) VALUES ('".$_POST['login']."','".$password."', '".$_POST['email']."')");
         if ($sql) {
//          require_once './views/registration_finish.php';
           echo "<p>Ви успішно зареєструвалися , тепер увійдіть на сайт під своїм іменем</p>";
        }
    }

}
       
?>


    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-9">
                <h2>Реєстрація на сайті</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <div class="input-group margin-bottom-sm">
                            <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                            <input class="form-control" type="text" name="login" placeholder="<?=$error_login;?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                            <input class="form-control" name="password" type="password" placeholder="<?=$error_pasword;?> ">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                            <input class="form-control" name="r_password" type="password" placeholder=" <?=$error_confirm;?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
                            <input class="form-control" type="text" name="email" placeholder="<?= $error_email;?>  ">
                        </div>
                    </div>


                    <button type="submit" class="btn btn-primary btn-md " name="submit">Зареєструватися</button>
                </form>
            </div>