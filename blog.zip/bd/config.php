<?php
    //$connection=new PDO('mysql:host=localhost;dbname=blog;charset=utf8','root','');
$connection = new mysqli("localhost", "root", "", "blog");
mysqli_query($connection, "SET NAMES 'utf8'");
if(!$connection){
    echo "no connection MYSQL";
}

?>