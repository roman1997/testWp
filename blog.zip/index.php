<?php 
    session_start();
    ini_set('display_errors','1');
    error_reporting(E_ALL);

     require_once 'bd/config.php';
     require_once 'layout/header.php';    
    if(isset($_GET["action"]) && file_exists('./views/' . $_GET["action"] . '.php')){ 
        require_once('./views/' . $_GET["action"] . '.php'); 
    } 
    else { 
        require_once("views/main.php"); 
    }
     require_once 'layout/side.php';     
     require_once 'layout/footer.php';     

?>