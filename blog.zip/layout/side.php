<?php
    $sql = "SELECT * FROM articles LIMIT 5";
    $sql2 = "SELECT * FROM category";
    $result = $connection->query($sql);
    $result2 = $connection->query($sql2);
?>
    <div class="col-xs-12 col-sm-6 col-md-3">

        <div class="recentPost">
            <h4 class="title">Категорії</h4>
            <ul class="list">
                <li><a href="?action=articles">Всі новини</a></li>
                <?php
                 if ($result2->num_rows > 0) {
        while($row = $result2->fetch_assoc()){
            ?>
                    <li>
                        <a href="?action=category&id=<?=$row['cat_id']?>">
                            <?=$row['cat_name']?>
                        </a>
                    </li>
                    <?php 
        }
                 }
?>
            </ul>
        </div>
        <div class="recentPost">
            <h4 class="title">Нові пости</h4>
            <ul class="list">
                <?php
                 if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()){
?>
                    <li><a href="?action=article&id=<?=$row['article_id']?>">
                        <?=$row['title']?>
                        </a>
                    </li>

                    <?php } }?>
            </ul>
        </div>

    </div>

    </div>
    </div>