<!DOCTYPE html>
<html lang="uk">

<head>
    <meta charset="utf-8">
    <title>Все цікаве в світі технологій</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" media="screen" href="style/bootstrap.css">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/font-awesome.min.css">
    <!--  -->

    <style>

    </style>

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="text-center logo">
                        <a href="index.php"><img src="img/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-9">
                    <ul class="nav navbar-nav navbar-right">
                       <?php
                           if ((isset($_SESSION['id'])) && ($_SESSION['id']>0) ) {      
                        ?>
                            <li><a href="?action=profile"><?php echo $_SESSION['login']?></a></li>
                            <?php
                                 if ((isset($_SESSION['admin'])) && ($_SESSION['admin']==1) ) {  
                            ?>
                            <li><a href="?action=add_post">Додати статтю </a></li>
                            <?php   }   ?>
                            
                            <li><a href="?action=logout">Вийти</a></li>
                        
                        <?php  } else{
                        ?>
                            <li><a href="?action=login">Вхід</a></li>
                            <li><a href="?action=registration">Реєстрація</a></li>
                       
                         <?php }?>
                        <!--
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Еще выпадающее <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Вхід</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Реєстрація</a></li>
                            </ul>
                        </li>
-->
                    </ul>

                </div>
            </div>
        </div>
    </header>