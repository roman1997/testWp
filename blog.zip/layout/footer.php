<!--
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/js/bootstrap.min.js"></script>
-->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4">
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
                <div class="post text-center">
                    <h3>Title</h3>
                    <p>Lorem ipsum</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<script>
</script>

</body>

</html>